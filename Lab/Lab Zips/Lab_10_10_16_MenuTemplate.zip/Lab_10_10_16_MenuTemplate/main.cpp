/* 
 * File:   main.cpp
 * Author: Jeffrey Thomas
 * Created on October 10, 2016, 09:40 AM
 * Purpose: 
 */

//System Libraries
#include <iostream> //Input/Output objects
using namespace std; //Namespace used in system library

//User libraries

//Global constants

//Function prototypes

//Execution begins here
int main(int argc, char** argv) 
{
    //Declaration of variables
    char menuItm;
    
    cout<<"1.  Type 1  for Problem A"<<endl;
    cout<<"2.  Type 2  for Problem B"<<endl;
    cout<<"3.  Type 3  for Problem C"<<endl;
    cout<<"4.  Type 4  for Problem D"<<endl;
    cout<<"5.  Type 5  for Problem E"<<endl;
    cout<<"6.  Type 6  for Problem F"<<endl;
    cout<<"7.  Type 7  for Problem G"<<endl;
    cout<<"8.  Type 8  for Problem H"<<endl;
    cout<<"9.  Type 9  for Problem I"<<endl;
    cout<<"10. Type 10 for Problem J"<<endl;
    cin>>menuItm;
    
    
    do{
        switch(menuItm){
            case 1:{
                //Input
                //Process
                //Output
                break;
            }
            case 2:{
                //Input
                //Process
                //Output
                break;
            }
            case 3:{
                //Input
                //Process
                //Output
                break;
            }
            case 4:{
                //Input
                //Process
                //Output
                break;
            }
            case 5:{
                //Input
                //Process
                //Output
                break;
            }
            case 6:{
                //Input
                //Process
                //Output
                break;
            }
            case 7:{
                //Input
                //Process
                //Output
                break;
            }
            case 8:{
                //Input
                //Process
                //Output
                break;
            }
            case 9:{
                //Input
                //Process
                //Output
                break;
            }
            case 10:{
                //Input
                //Process
                //Output
                break;
            }
        }
    }while(menuItm>0&&menuItm<11);
    
    //Exit program
    return 0;
}

